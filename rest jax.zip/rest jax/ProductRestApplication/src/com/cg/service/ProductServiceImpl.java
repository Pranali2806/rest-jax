package com.cg.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.websocket.server.PathParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import com.cg.entity.Response;
import com.cg.entity.Product;

public class ProductServiceImpl implements ProductService {
	
private static Map<Integer, Product> products = new HashMap<Integer,Product>();
	
	@Override
	@POST
    @Path("/add")
	public Response addProduct(Product p) {
		Response response = new Response();
		if(products.get(p.getProdId()) != null){
			response.setStatus(false);
			response.setMessage("Product Already Exists");
			return response;
		}
		products.put(p.getProdId(), p);
		response.setStatus(true);
		response.setMessage("Product created successfully");
		return response;
	}

	@Override
	@GET
    @Path("/{id}/delete")
	public Response deleteProduct(@PathParam("id") int id) {
		Response response = new Response();
		if(products.get(id) == null){
			response.setStatus(false);
			response.setMessage("Product Doesn't Exists");
			return response;
		}
		products.remove(id);
		response.setStatus(true);
		response.setMessage("Product deleted successfully");
		return response;
	}

	@Override
	@GET
	@Path("/{id}/get")
	public Product getProduct(@PathParam("id") int id) {
		return products.get(id);
	}
	
	@GET
	@Path("/{id}/getDummy")
	public Product getDummyPerson(@PathParam("id") int id) {
		Product p = new Product();
		p.setProdPrice(99);
		p.setProdName("Dummy");
		p.setProdId(id);
		return p;
	}

	@Override
	@GET
	@Path("/getAll")
	public Product[] getAllProducts() {
		Set<Integer> ids = products.keySet();
		Product[] p = new Product[ids.size()];
		int i=0;
		for(Integer id : ids){
			p[i] = products.get(id);
			i++;
		}
		return p;
	}

}
