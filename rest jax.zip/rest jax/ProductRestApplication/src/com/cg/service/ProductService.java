package com.cg.service;

import com.cg.entity.Product;
import com.cg.entity.Response;

public interface ProductService {
	
	public Response addProduct(Product p);
	
	public Response deleteProduct(int id);
	
	public Product getProduct(int id);
	
	public Product[] getAllProducts();
}
