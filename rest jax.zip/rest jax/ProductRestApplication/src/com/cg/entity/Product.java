package com.cg.entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement (name="product")
public class Product {
	
	private String prodName;
	private int prodId;
	private int prodPrice;
	
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public int getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(int prodPrice) {
		this.prodPrice = prodPrice;
	}
	@Override
	public String toString() {
		return "Product [prodName=" + prodName + ", prodId=" + prodId + ", prodPrice=" + prodPrice + "]";
	}
}
